/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//ST10404581 - Sahibzada Hameed

package ice.task.pkg1.s2.pkg2023;

import java.util.Scanner;

/**
 *
 * @author Hameed
 */
public class Animal {
    
    //CREATING A SCANNER OBJECT THAT CAN BE USED IN THE THIS CLASS AND 
    //IT'S SUBCLASSES
    public static Scanner kb = new Scanner(System.in);
    
    public Animal(){
        
    }
    private String species;
    private int IDtag;

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public int getIDtag() {
        return IDtag;
    }

    public void setIDtag(int IDtag) {
        this.IDtag = IDtag;
    }
    
    //input IS USED TO GET INPUT FROM THE USER
    public void input(){
        System.out.println("Enter in the animal's species: ");
        species = kb.next();
        setSpecies(species);
        System.out.println("Enter in the ID tag number of the animal: ");
        IDtag = kb.nextInt();
        setIDtag(IDtag);
    }
    
    //output DISPLAYS THE NECESSARY INFORMATION
    public void output(){
        System.out.println("Species: " + getSpecies());
        System.out.println("ID tag number: " + getIDtag());
    }
}
