/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//ST10404581 - Sahibzada Hameed
package ice.task.pkg1.s2.pkg2023;

import java.util.Scanner;

/**
 *
 * @author Hameed
 */
public class Bird extends Animal {

    private int colour;

    public int getColour() {
        return colour;
    }

    public void setColour(int colour) {
        this.colour = colour;
    }

    @Override
    public void input() {
        System.out.println("----------Bird----------");
        super.input();
        System.out.println("Enter the colour of the bird's feathers:\n1 for Grey feathers\n2 for White feathers\n3 for Black feathers");
        colour = kb.nextInt();
        setColour(colour);
    }

    @Override
    public void output() {
        System.out.println("----------Animal Details----------");
        System.out.println("Animal type: Bird");
        super.output();
        //THE SWITCH STATEMENT DETERMINES THE OUTPUT DEPENDING ON THE INPUT THE 
        //USER GAVE
        switch (colour) {
            case 1:
                System.out.println("The colour of the bird's feathers is: Grey");
                break;
            case 2:
                System.out.println("The colour of the bird's feathers is: White");
                break;
            case 3:
                System.out.println("The colour of the bird's feathers is: Black");
                break;
            default:
                throw new AssertionError();
        }
    }

}
