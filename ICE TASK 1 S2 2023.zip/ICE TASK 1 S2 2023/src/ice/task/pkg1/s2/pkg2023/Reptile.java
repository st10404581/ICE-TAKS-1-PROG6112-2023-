/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//ST10404581 - Sahibzada Hameed

package ice.task.pkg1.s2.pkg2023;

import java.util.Scanner;

/**
 *
 * @author Hameed
 */
public class Reptile extends Animal {

    private double bloodTemp;
    public static Scanner kb = new Scanner(System.in);

    public double getBloodTemp() {
        return bloodTemp;
    }

    public void setBloodTemp(double bloopTemp) {
        this.bloodTemp = bloopTemp;
    }

    @Override
    public void input() {
        System.out.println("----------Reptile----------");
        super.input();
        System.out.println("Enter the blood temperature of the animal: ");
        bloodTemp = kb.nextDouble();
        setBloodTemp(bloodTemp);
    }

    @Override
    public void output() {
        System.out.println("----------Animal Details----------");
        System.out.println("Animal type: Reptile");
        super.output();
        System.out.println("The temperature of the reptile is " + getBloodTemp());
    }
}
