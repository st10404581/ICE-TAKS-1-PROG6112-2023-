/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
//ST10404581 - Sahibzada Hameed
package ice.task.pkg1.s2.pkg2023;

import java.util.Scanner;

/**
 *
 * @author Hameed
 */
public class ICETASK1S22023 {

    public static Scanner kb = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int userChoice = 0;

        //DISPLAYING A HEADING AND GETTING INPUT FROM THE USER
        System.out.println("------Yuri Zoo Animal Administrative Program------");
        System.out.println("Please enter if the animal you would like to add is a "
                + "Bird(1) or a Reptile(2)");
        userChoice = kb.nextInt();

        //CREATING THE CLASS OBJECTS
        Bird brd = new Bird();
        Reptile rept = new Reptile();

        //THIS BOOLEAN VARAIBLE IS USED TO DETERMINET WEITHER LOOPING INPUT FROM 
        //THE USER IS REQUIRED OR NOT
        //TRUE - VALID AND FALSE = INVALID
        boolean isValid = true;

        if ((userChoice != 1) && (userChoice != 2)) {
            isValid = false;
        }//END OF IF STATEMENT

        while (isValid == false) {
            System.out.println("Error.. Please enter 1 if the animal is a Bird "
                    + "or 2 if the animal is a Reptile");
            userChoice = kb.nextInt();
            if ((userChoice == 1) || (userChoice == 2)) {
                isValid = true;
            }//END OF IF STATEMENT
        }//END OF WHILE STATEMENT

        if (isValid == true) {
            switch (userChoice) {
                case 1:
                    brd.input();
                    brd.output();
                    break;
                case 2:
                    rept.input();
                    rept.output();
                    break;
                default:
                    throw new AssertionError();
            }//END OF SWITCH CASE 
        }//END OF SWITCH CASE

    }//END OF MAIN

}
